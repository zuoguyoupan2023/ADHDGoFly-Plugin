// ADHDGoFly 安装配置 - 构建时自动生成
window.ADHD_INSTALL_CONFIG = {
  "installType": "selfinstallmark",
  "targetBrowser": "chrome",
  "version": "0.1.8",
  "buildTime": "2026-07-22T04:43:24.540Z",
  "storeUrl": "https://feedback.readgofly.online/",
  "reviewAutoResetOnMajor": true,
  "reviewAutoClearReviewedOnMajor": true
};

// 获取安装类型的便捷函数
window.getInstallType = function() {
    return window.ADHD_INSTALL_CONFIG ? window.ADHD_INSTALL_CONFIG.installType : 'selfinstallmark';
};

// 获取商店链接的便捷函数（智能回退支持）
window.getStoreUrl = function() {
    if (!window.ADHD_INSTALL_CONFIG) {
        return 'https://feedback.readgofly.online/';
    }
    
    const config = window.ADHD_INSTALL_CONFIG;
    
    
    return config.storeUrl;
};

// 获取Chrome商店搜索提示信息
window.getChromeStoreHint = function() {
    if (window.ADHD_INSTALL_CONFIG && window.ADHD_INSTALL_CONFIG.chromeStoreFallback) {
        return window.ADHD_INSTALL_CONFIG.chromeStoreFallback;
    }
    return null;
};

// 获取主版本重置开关
window.getReviewAutoResetOnMajor = function() {
    if (!window.ADHD_INSTALL_CONFIG) return true;
    return !!window.ADHD_INSTALL_CONFIG.reviewAutoResetOnMajor;
};

// 获取主版本清除已评价开关
window.getReviewAutoClearOnMajor = function() {
    if (!window.ADHD_INSTALL_CONFIG) return true;
    return !!window.ADHD_INSTALL_CONFIG.reviewAutoClearReviewedOnMajor;
};