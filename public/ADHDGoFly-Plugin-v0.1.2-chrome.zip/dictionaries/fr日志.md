Uncaught SyntaxError: Identifier 'DictionaryManager' has already been declared (at dictionary-manager.js:1:1)
main.js:882 加载ADHD文本高亮器主控制器...
main.js:43 初始化ADHD文本高亮器...
main.js:894 ADHD文本高亮器主控制器加载完成
dictionary-manager-new.js:39 Dictionary registry loaded: 
{version: '1.0.0', lastUpdated: '2024-01-01', dictionaries: {…}, settings: {…}}
dictionary-manager-new.js:22 DictionaryManager initialized successfully
dictionary-manager-new.js:128 Dictionary loaded: zh-preset
dictionary-adapter.js:77 Loaded dictionary: zh (349176 words)
dictionary-manager-new.js:128 Dictionary loaded: en-preset
dictionary-adapter.js:77 Loaded dictionary: en (148836 words)
dictionary-manager-new.js:128 Dictionary loaded: es-preset
dictionary-adapter.js:77 Loaded dictionary: es (76887 words)
dictionary-manager-new.js:128 Dictionary loaded: fr-preset
dictionary-adapter.js:77 Loaded dictionary: fr (143674 words)
dictionary-manager-new.js:128 Dictionary loaded: ja-preset
dictionary-adapter.js:77 Loaded dictionary: ja (204724 words)
dictionary-manager-new.js:128 Dictionary loaded: ru-preset
dictionary-adapter.js:77 Loaded dictionary: ru (331931 words)
dictionary-adapter.js:49 DictionaryAdapter initialized successfully
main.js:201 加载词典设置: 
{"": true, en: false, es: false, fr: true, ja: false, …}
dictionary-adapter.js:215 Updating enabled languages: 
{"": true, en: false, es: false, fr: true, ja: false, …}
dictionary-adapter.js:232 Syncing enabled languages to registry: 
{"": true, en: false, es: false, fr: true, ja: false, …}
main.js:227 加载颜色设置: default
main.js:332 颜色方案已应用: default
main.js:234 加载高亮开关设置: 
{adj: true, comparative: false, noun: true, verb: true}
main.js:239 TextSegmenter高亮开关设置已加载: 
{noun: true, verb: true, adj: true, comparative: false}
main.js:356 加载文本设置: 
{fontSize: 115, letterSpacing: 0, lineHeight: 1.5, paragraphSpacing: 0}
main.js:428 文本设置已应用到高亮词汇: 
{fontSize: 115, letterSpacing: 0, lineHeight: 1.5, paragraphSpacing: 0}
main.js:429 字号倍数: 1.15em
main.js:459 启用文本高亮...
page-processor.js:31 开始处理页面...
page-processor.js:42 找到 36 个文本节点
page-processor.js:53 页面处理完成: 
{processedNodes: 1, highlightedWords: 1, skippedNodes: 35, errors: 0}
main.js:332 颜色方案已应用: default
main.js:428 文本设置已应用到高亮词汇: 
{fontSize: 115, letterSpacing: 0, lineHeight: 1.5, paragraphSpacing: 0}
main.js:429 字号倍数: 1.15em
main.js:474 文本高亮已启用
main.js:67 ADHD文本高亮器初始化完成