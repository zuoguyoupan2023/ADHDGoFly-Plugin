帮我总结这篇文章: https://fontawesome.com/v4/community/#requesting-new-icons
存储的详情: 32 段
章节1: ROOT 预览: Font Awesome 4 is so 2017.
Upgrade to version 5 and get twice the icons.
Get the Latest
Font Awesome
Home
What's New
Get Started
Icons
Toggle dropdown menu
Examples
Toggle dropdown menu
Accessibility
Community
License
Community
Lots of ways to get involved with Font Awesome
Follow @fontawesome
Tweet
章节2: Community 预览: Lots of ways to get involved with Font Awesome
Follow @fontawesome
Tweet
Follow @fontawesome
Tweet
Check out the latest remote job listings from Authentic Jobs.
ads via Carbon
Font Awesome has a vibrant community of folks helping each other out. You can
get support,
report bugs,
request new icons,
s
章节3: Requesting New Icons 预览: New icons mostly start as requests by the
Font Awesome community on GitHub
. Want to request a new icon? Here are some things to keep in mind:
Please be nice. Font Awesome is a happy place.
Please
search
to see if your icon request already exists. If a request is found, please add a 👍 reaction to t
章节4: Getting Support 预览: Having trouble getting Font Awesome up and running? Something not working the way you think it should? I hate that I don't have time to answer Font Awesome support emails anymore. So here are some things you might wanna do:
Make sure you've read the latest version of how to
get started
. It's been u
章节5: Project Milestones 预览: Want to keep up with what's planned for Font Awesome? Check out our
milestones
on the GitHub project.
Thanks To
Thanks to
@robmadole
and
@supercodepoet
for icon design review, advice, some Jekyll help, and being all around badass coders.
HUGE thanks to
@gtagliala
for doing such a fantastic job manag

Font Awesome 4 is so 2017.
Upgrade to version 5 and get twice the icons.
Get the Latest
Font Awesome
Home
What's New
Get Started
Icons
Toggle dropdown menu
Examples
Toggle dropdown menu
Accessibility
Community
License
Community
Lots of ways to get involved with Font Awesome
Follow @fontawesome
Tweet
Check out the latest remote job listings from Authentic Jobs.
ads via Carbon
Font Awesome has a vibrant community of folks helping each other out. You can
get support,
report bugs,
request new icons,
submit pull requests
, and
check upcoming milestones.
Getting Support
Having trouble getting Font Awesome up and running? Something not working the way you think it should? I hate that I don't have time to answer Font Awesome support emails anymore. So here are some things you might wanna do:
Make sure you've read the latest version of how to
get started
. It's been updated recently to make Font Awesome even easier to use.
Check out the
existing questions tagged as Font Awesome
over on Stack Overflow. Other folks might have had the same question you've had.
Can't find the answer to your question on Stack Overflow?
Ask a new question
, then
send me an email
and I might be able to take a look.
Requesting New Icons
New icons mostly start as requests by the
Font Awesome community on GitHub
. Want to request a new icon? Here are some things to keep in mind:
Please be nice. Font Awesome is a happy place.
Please
search
to see if your icon request already exists. If a request is found, please add a 👍 reaction to that one.
Please make requests for single icons, unless you are requesting a couple of strictly related icons (e.g., thumbs-up/thumbs-down).
Please and thank you if you include the following:
Title your
new issue
Icon request: icon-name
(e.g.,
Icon request: icon-car
).
Include a few use cases for your requested icon. How do you plan on using it?
Attach a single color image or two that represent the idea you're going for.
Request concrete objects: it's harder to make an icon to represent happiness, it's easier to make a smiley face.
Reporting Bugs
Found a problem with Font Awesome? Feel free to submit an issue on the GitHub project. But please keep the following in mind:
Please be nice. Font Awesome is a happy place.
Please
search
to see if your bug was already reported.
Before opening any issue, please read the generic
issue guidelines
, by
Nicolas Gallagher.
After doing everything above, feel free to
submit an issue.
Submitting Pull Requests
Found a way to solve a bug in Font Awesome? Want to contribute new features? Here are a few things to remember:
Please do not submit new icons.
Please submit all pull requests against *-wip branches.
All pull requests submitted against master will be summarily closed and this guide referenced.
After doing everything above, feel free to
submit a pull request.
Project Milestones
Want to keep up with what's planned for Font Awesome? Check out our
milestones
on the GitHub project.
Thanks To
Thanks to
@robmadole
and
@supercodepoet
for icon design review, advice, some Jekyll help, and being all around badass coders.
HUGE thanks to
@gtagliala
for doing such a fantastic job managing pull requests and issues on the Font Awesome
GitHub project.
Thanks to
MaxCDN
for providing the excellent
BootstrapCDN
, the fastest and easiest way to
get started
with Font Awesome.
Font Awesome 4 is so 2017.
Upgrade to version 5 and get twice the icons.
Get the Latest
Font Awesome 4 is so 2017.
Upgrade to version 5 and get twice the icons.
Get the Latest
Font Awesome
Home
What's New
Get Started
Icons
Toggle dropdown menu
Examples
Toggle dropdown menu
Accessibility
Community
License
Font Awesome
Home
What's New
Get Started
Icons
Toggle dropdown menu
Examples
Toggle dropdown menu
Accessibility
Community
License
Home
What's New
Get Started
Icons
Toggle dropdown menu
Examples
Accessibility
Community
License
Community
Lots of ways to get involved with Font Awesome

Lots of ways to get involved with Font Awesome
Follow @fontawesome
Tweet
Follow @fontawesome
Tweet
Check out the latest remote job listings from Authentic Jobs.
ads via Carbon
Font Awesome has a vibrant community of folks helping each other out. You can
get support,
report bugs,
request new icons,
submit pull requests
, and
check upcoming milestones.
Getting Support
Having trouble getting Font Awesome up and running? Something not working the way you think it should? I hate that I don't have time to answer Font Awesome support emails anymore. So here are some things you might wanna do:
Make sure you've read the latest version of how to
get started
. It's been updated recently to make Font Awesome even easier to use.
Check out the
existing questions tagged as Font Awesome
over on Stack Overflow. Other folks might have had the same question you've had.
Can't find the answer to your question on Stack Overflow?
Ask a new question
, then
send me an email
and I might be able to take a look.
Requesting New Icons
New icons mostly start as requests by the
Font Awesome community on GitHub
. Want to request a new icon? Here are some things to keep in mind:
Please be nice. Font Awesome is a happy place.
Please
search
to see if your icon request already exists. If a request is found, please add a 👍 reaction to that one.
Please make requests for single icons, unless you are requesting a couple of strictly related icons (e.g., thumbs-up/thumbs-down).
Please and thank you if you include the following:
Title your
new issue
Icon request: icon-name
(e.g.,
Icon request: icon-car
).
Include a few use cases for your requested icon. How do you plan on using it?
Attach a single color image or two that represent the idea you're going for.
Request concrete objects: it's harder to make an icon to represent happiness, it's easier to make a smiley face.
Reporting Bugs
Found a problem with Font Awesome? Feel free to submit an issue on the GitHub project. But please keep the following in mind:
Please be nice. Font Awesome is a happy place.
Please
search
to see if your bug was already reported.
Before opening any issue, please read the generic
issue guidelines
, by
Nicolas Gallagher.
After doing everything above, feel free to
submit an issue.
Submitting Pull Requests
Found a way to solve a bug in Font Awesome? Want to contribute new features? Here are a few things to remember:
Please do not submit new icons.
Please submit all pull requests against *-wip branches.
All pull requests submitted against master will be summarily closed and this guide referenced.
After doing everything above, feel free to
submit a pull request.
Project Milestones
Want to keep up with what's planned for Font Awesome? Check out our
milestones
on the GitHub project.
Thanks To
Thanks to
@robmadole
and
@supercodepoet
for icon design review, advice, some Jekyll help, and being all around badass coders.
HUGE thanks to
@gtagliala
for doing such a fantastic job managing pull requests and issues on the Font Awesome
GitHub project.
Thanks to
MaxCDN
for providing the excellent
BootstrapCDN
, the fastest and easiest way to
get started
with Font Awesome.
Check out the latest remote job listings from Authentic Jobs.
ads via Carbon
Font Awesome has a vibrant community of folks helping each other out. You can
get support,
report bugs,
request new icons,
submit pull requests
, and
check upcoming milestones.
Check out the latest remote job listings from Authentic Jobs.
ads via Carbon
Font Awesome has a vibrant community of folks helping each other out. You can
get support,
report bugs,
request new icons,
submit pull requests
, and
check upcoming milestones.
Getting Support
Having trouble getting Font Awesome up and running? Something not working the way you think it should? I hate that I don't have time to answer Font Awesome support emails anymore. So here are some things you might wanna do:
Make sure you've read the latest version of how to
get started
. It's been updated recently to make Font Awesome even easier to use.
Check out the
existing questions tagged as Font Awesome
over on Stack Overflow. Other folks might have had the same question you've had.
Can't find the answer to your question on Stack Overflow?
Ask a new question
, then
send me an email
and I might be able to take a look.

New icons mostly start as requests by the
Font Awesome community on GitHub
. Want to request a new icon? Here are some things to keep in mind:
Please be nice. Font Awesome is a happy place.
Please
search
to see if your icon request already exists. If a request is found, please add a 👍 reaction to that one.
Please make requests for single icons, unless you are requesting a couple of strictly related icons (e.g., thumbs-up/thumbs-down).
Please and thank you if you include the following:
Title your
new issue
Icon request: icon-name
(e.g.,
Icon request: icon-car
).
Include a few use cases for your requested icon. How do you plan on using it?
Attach a single color image or two that represent the idea you're going for.
Title your
new issue
Icon request: icon-name
(e.g.,
Icon request: icon-car
).
Include a few use cases for your requested icon. How do you plan on using it?
Attach a single color image or two that represent the idea you're going for.
Request concrete objects: it's harder to make an icon to represent happiness, it's easier to make a smiley face.
Reporting Bugs
Found a problem with Font Awesome? Feel free to submit an issue on the GitHub project. But please keep the following in mind:
Please be nice. Font Awesome is a happy place.
Please
search
to see if your bug was already reported.
Before opening any issue, please read the generic
issue guidelines
, by
Nicolas Gallagher.
After doing everything above, feel free to
submit an issue.

Having trouble getting Font Awesome up and running? Something not working the way you think it should? I hate that I don't have time to answer Font Awesome support emails anymore. So here are some things you might wanna do:
Make sure you've read the latest version of how to
get started
. It's been updated recently to make Font Awesome even easier to use.
Check out the
existing questions tagged as Font Awesome
over on Stack Overflow. Other folks might have had the same question you've had.
Can't find the answer to your question on Stack Overflow?
Ask a new question
, then
send me an email
and I might be able to take a look.
Requesting New Icons
New icons mostly start as requests by the
Font Awesome community on GitHub
. Want to request a new icon? Here are some things to keep in mind:
Please be nice. Font Awesome is a happy place.
Please
search
to see if your icon request already exists. If a request is found, please add a 👍 reaction to that one.
Please make requests for single icons, unless you are requesting a couple of strictly related icons (e.g., thumbs-up/thumbs-down).
Please and thank you if you include the following:
Title your
new issue
Icon request: icon-name
(e.g.,
Icon request: icon-car
).
Include a few use cases for your requested icon. How do you plan on using it?
Attach a single color image or two that represent the idea you're going for.
Request concrete objects: it's harder to make an icon to represent happiness, it's easier to make a smiley face.

Want to keep up with what's planned for Font Awesome? Check out our
milestones
on the GitHub project.
Thanks To
Thanks to
@robmadole
and
@supercodepoet
for icon design review, advice, some Jekyll help, and being all around badass coders.
HUGE thanks to
@gtagliala
for doing such a fantastic job managing pull requests and issues on the Font Awesome
GitHub project.
Thanks to
MaxCDN
for providing the excellent
BootstrapCDN
, the fastest and easiest way to
get started
with Font Awesome.

Please do not submit new icons.
Please submit all pull requests against *-wip branches.
All pull requests submitted against master will be summarily closed and this guide referenced.
After doing everything above, feel free to
submit a pull request.
Project Milestones
Want to keep up with what's planned for Font Awesome?

Found a pr
收起