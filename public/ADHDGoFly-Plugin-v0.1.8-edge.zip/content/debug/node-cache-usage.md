# 节点级缓存功能使用说明

## 概述

节点级缓存是ADHDGoFly插件的核心性能优化功能，通过缓存已处理的文本节点来避免重复的分词和高亮处理，显著提升页面处理速度。

## 主要组件

### 1. NodeLevelCacheManager
- **位置**: `content/storage/node-level-cache-manager.js`
- **功能**: 管理节点级缓存的存储、检索和维护
- **存储**: 使用IndexedDB进行持久化存储

### 2. StreamingPageProcessor集成
- **位置**: `content/streaming-page-processor.js`
- **功能**: 在文本处理流程中集成缓存检查和存储

### 3. 性能监控工具
- **位置**: `content/debug/cache-performance-monitor.js`
- **功能**: 实时监控缓存性能和统计

## 核心功能

### 节点指纹生成
```javascript
// 为文本节点生成唯一指纹
const fingerprint = cacheManager.generateNodeFingerprint(textNode, pageUrl);
// 返回: { contentHash, lightXPath, parentSignature }
```

### 缓存操作
```javascript
// 存储缓存
await cacheManager.storeNodeCache(fingerprint, language, cacheData);

// 检索缓存
const cachedResult = await cacheManager.getNodeCache(fingerprint, language);

// 验证缓存有效性
const isValid = cacheManager.validateCacheEntry(cachedResult, textNode, pageUrl);
```

### 性能统计
```javascript
// 获取详细性能统计
const stats = await cacheManager.getPerformanceStats();
console.log('缓存命中率:', stats.hitRate);
console.log('总查询次数:', stats.totalQueries);
```

## 缓存策略

### 1. 缓存键生成
- **内容哈希**: 基于节点文本内容的MD5哈希
- **轻量XPath**: 简化的DOM路径标识
- **父节点签名**: 父节点的结构特征

### 2. 缓存验证
- **过期检查**: 默认24小时过期
- **内容一致性**: 验证文本内容是否变化
- **页面匹配**: 确保在相同页面上使用
- **路径相似性**: 检查DOM结构变化

### 3. 缓存维护
- **自动清理**: 定期清理过期条目
- **智能淘汰**: 基于访问频率的LRU策略
- **存储限制**: 最大10000个缓存条目

## 性能监控

### 开发者工具
```javascript
// 启动性能监控
window.debugCache.startMonitoring();

// 查看实时统计
window.debugCache.logCurrentStats();

// 生成性能报告
const report = window.debugCache.generateReport();

// 导出性能数据
window.debugCache.exportData();
```

### 关键指标
- **命中率**: 缓存命中次数 / 总查询次数
- **平均查询时间**: 缓存操作的平均耗时
- **存储效率**: 成功存储 / 尝试存储
- **内存使用**: 估算的缓存大小

## 测试验证

### 自动化测试
```javascript
// 运行完整测试套件
const results = await window.testNodeCache();

// 查看测试结果
console.log('测试通过率:', results.summary.passed / results.summary.total);
```

### 手动测试步骤
1. 打开包含大量文本的页面
2. 启用插件并等待处理完成
3. 刷新页面，观察处理速度提升
4. 使用开发者工具查看缓存统计

## 配置选项

### 缓存设置
```javascript
const config = {
  maxCacheSize: 10000,        // 最大缓存条目数
  cacheExpiration: 86400000,  // 过期时间(毫秒)
  enableFallback: true,       // 启用降级模式
  compressionLevel: 1         // 压缩级别
};
```

### 性能调优
- **批量操作**: 使用事务进行批量缓存操作
- **延迟清理**: 在空闲时间进行缓存维护
- **内存监控**: 监控内存使用避免过度缓存

## 故障排除

### 常见问题

1. **缓存未命中**
   - 检查节点内容是否发生变化
   - 验证页面URL是否匹配
   - 确认缓存未过期

2. **存储失败**
   - 检查IndexedDB是否可用
   - 验证数据格式是否正确
   - 确认存储空间是否充足

3. **性能下降**
   - 检查缓存大小是否过大
   - 验证清理机制是否正常工作
   - 考虑调整缓存策略

### 调试工具
```javascript
// 检查缓存状态
console.log(await cacheManager.getPerformanceStats());

// 清空所有缓存
await cacheManager.clearAllCache();

// 手动触发维护
await cacheManager.performMaintenance();
```

## 最佳实践

1. **合理设置缓存大小**: 根据用户设备性能调整
2. **定期监控性能**: 使用内置监控工具
3. **及时清理缓存**: 在适当时机清理过期数据
4. **错误处理**: 实现完善的错误处理和降级机制
5. **用户反馈**: 收集用户体验反馈进行优化

## 版本兼容性

- **Chrome**: 88+
- **Firefox**: 85+
- **Safari**: 14+
- **Edge**: 88+

## 更新日志

### v1.0.0
- 初始版本发布
- 基本缓存功能实现
- 性能监控工具
- 自动化测试套件